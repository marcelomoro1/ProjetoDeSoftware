package com.mjwsolucoes.sistemanutricao.service;

import com.mjwsolucoes.sistemanutricao.model.IngredienteNutricionista;
import com.mjwsolucoes.sistemanutricao.model.Nutricionista;
import com.mjwsolucoes.sistemanutricao.repository.IngredienteNutricionistaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class IngredienteNutricionistaService {

    private final IngredienteNutricionistaRepository ingredienteNutricionistaRepository;

    public IngredienteNutricionistaService(IngredienteNutricionistaRepository ingredienteNutricionistaRepository) {
        this.ingredienteNutricionistaRepository = ingredienteNutricionistaRepository;
    }

    @Transactional
    public IngredienteNutricionista criar(IngredienteNutricionista ingrediente, Nutricionista nutricionista) {
        validarIngrediente(ingrediente);
        ingrediente.setNutricionista(nutricionista);

        if (ingredienteNutricionistaRepository.findByNomeAndNutricionista(
                ingrediente.getNome(), nutricionista).isPresent()) {
            throw new IllegalStateException("Já existe um ingrediente com este nome para o nutricionista");
        }

        return ingredienteNutricionistaRepository.save(ingrediente);
    }

    @Transactional(readOnly = true)
    public List<IngredienteNutricionista> listarPorNutricionista(Nutricionista nutricionista) {
        return ingredienteNutricionistaRepository.findByNutricionista(nutricionista);
    }

    @Transactional(readOnly = true)
    public List<IngredienteNutricionista> buscarLowCarb(Nutricionista nutricionista, BigDecimal maxCarboidratos) {
        if (maxCarboidratos == null || maxCarboidratos.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Valor máximo de carboidratos inválido");
        }
        return ingredienteNutricionistaRepository.findLowCarb(maxCarboidratos, nutricionista);
    }

    @Transactional
    public IngredienteNutricionista atualizar(Long id, IngredienteNutricionista novosDados, Nutricionista nutricionista) {
        IngredienteNutricionista existente = ingredienteNutricionistaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Ingrediente não encontrado"));

        if (!existente.getNutricionista().equals(nutricionista)) {
            throw new IllegalStateException("Acesso não autorizado a este ingrediente");
        }

        validarIngrediente(novosDados);
        existente.setNome(novosDados.getNome());
        existente.setProteinaPor100g(novosDados.getProteinaPor100g());
        existente.setCarboidratoPor100g(novosDados.getCarboidratoPor100g());
        existente.setLipidioPor100g(novosDados.getLipidioPor100g());
        existente.setSodioPor100g(novosDados.getSodioPor100g());
        existente.setGorduraSaturadaPor100g(novosDados.getGorduraSaturadaPor100g());

        return ingredienteNutricionistaRepository.save(existente);
    }

    @Transactional
    public void excluir(Long id, Nutricionista nutricionista) {
        IngredienteNutricionista ingrediente = ingredienteNutricionistaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Ingrediente não encontrado"));

        if (!ingrediente.getNutricionista().equals(nutricionista)) {
            throw new IllegalStateException("Acesso não autorizado a este ingrediente");
        }

        ingredienteNutricionistaRepository.delete(ingrediente);
    }

    private void validarIngrediente(IngredienteNutricionista ingrediente) {
        if (ingrediente.getNome() == null || ingrediente.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do ingrediente é obrigatório");
        }

        validarValorNutricional(ingrediente.getProteinaPor100g(), "Proteína");
        validarValorNutricional(ingrediente.getCarboidratoPor100g(), "Carboidrato");
        validarValorNutricional(ingrediente.getLipidioPor100g(), "Lipídio");
        validarValorNutricional(ingrediente.getSodioPor100g(), "Sódio");
        validarValorNutricional(ingrediente.getGorduraSaturadaPor100g(), "Gordura saturada");
    }

    private void validarValorNutricional(BigDecimal valor, String campo) {
        if (valor == null || valor.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException(campo + " não pode ser negativo");
        }
    }
}