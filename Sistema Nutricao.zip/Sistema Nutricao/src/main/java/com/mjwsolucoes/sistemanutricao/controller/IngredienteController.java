package com.mjwsolucoes.sistemanutricao.controller;

public class IngredienteController {
}
