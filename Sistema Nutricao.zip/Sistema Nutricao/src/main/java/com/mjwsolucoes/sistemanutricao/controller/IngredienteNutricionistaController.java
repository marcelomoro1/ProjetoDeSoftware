package com.mjwsolucoes.sistemanutricao.controller;

public class IngredienteNutricionistaController {
}
