package com.mjwsolucoes.sistemanutricao.repository;

import com.mjwsolucoes.sistemanutricao.model.Ingrediente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface IngredienteRepository extends JpaRepository<Ingrediente, Long> {

    // Busca por nome exato (case insensitive)
    Optional<Ingrediente> findByNomeIgnoreCase(String nome);

    // Busca por parte do nome (contains) - case insensitive
    List<Ingrediente> findByNomeContainingIgnoreCase(String nome);

    // Busca ingredientes com proteína acima de um valor
    @Query("SELECT i FROM Ingrediente i WHERE i.proteinaPor100g >= :valor")
    List<Ingrediente> findComProteinaAcimaDe(@Param("valor") BigDecimal valor);

    // Busca ordenada por nome
    List<Ingrediente> findAllByOrderByNomeAsc();
}