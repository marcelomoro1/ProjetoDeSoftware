package com.mjwsolucoes.sistemanutricao.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "ingredientes")
public class Ingrediente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(precision = 10, scale = 2)
    private BigDecimal proteinaPor100g;

    @Column(precision = 10, scale = 2)
    private BigDecimal carboidratoPor100g;

    @Column(precision = 10, scale = 2)
    private BigDecimal lipidioPor100g;

    @Column(precision = 10, scale = 2)
    private BigDecimal sodioPor100g;

    @Column(precision = 10, scale = 2)
    private BigDecimal gorduraSaturadaPor100g;

    public Ingrediente() {
    }

    public Ingrediente(String nome, BigDecimal proteinaPor100g, BigDecimal carboidratoPor100g, BigDecimal sodioPor100g, BigDecimal gorduraSaturadaPor100g, BigDecimal lipidioPor100g) {
        this.nome = nome;
        this.proteinaPor100g = proteinaPor100g;
        this.carboidratoPor100g = carboidratoPor100g;
        this.sodioPor100g = sodioPor100g;
        this.gorduraSaturadaPor100g = gorduraSaturadaPor100g;
        this.lipidioPor100g = lipidioPor100g;
    }

    public Ingrediente(Long id, String nome, BigDecimal proteinaPor100g, BigDecimal carboidratoPor100g, BigDecimal lipidioPor100g, BigDecimal sodioPor100g, BigDecimal gorduraSaturadaPor100g) {
        this.id = id;
        this.nome = nome;
        this.proteinaPor100g = proteinaPor100g;
        this.carboidratoPor100g = carboidratoPor100g;
        this.lipidioPor100g = lipidioPor100g;
        this.sodioPor100g = sodioPor100g;
        this.gorduraSaturadaPor100g = gorduraSaturadaPor100g;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getProteinaPor100g() {
        return proteinaPor100g;
    }

    public void setProteinaPor100g(BigDecimal proteinaPor100g) {
        this.proteinaPor100g = proteinaPor100g;
    }

    public BigDecimal getCarboidratoPor100g() {
        return carboidratoPor100g;
    }

    public void setCarboidratoPor100g(BigDecimal carboidratoPor100g) {
        this.carboidratoPor100g = carboidratoPor100g;
    }

    public BigDecimal getLipidioPor100g() {
        return lipidioPor100g;
    }

    public void setLipidioPor100g(BigDecimal lipidioPor100g) {
        this.lipidioPor100g = lipidioPor100g;
    }

    public BigDecimal getSodioPor100g() {
        return sodioPor100g;
    }

    public void setSodioPor100g(BigDecimal sodioPor100g) {
        this.sodioPor100g = sodioPor100g;
    }

    public BigDecimal getGorduraSaturadaPor100g() {
        return gorduraSaturadaPor100g;
    }

    public void setGorduraSaturadaPor100g(BigDecimal gorduraSaturadaPor100g) {
        this.gorduraSaturadaPor100g = gorduraSaturadaPor100g;
    }
}