package com.mjwsolucoes.sistemanutricao.repository;

import com.mjwsolucoes.sistemanutricao.model.IngredienteNutricionista;
import com.mjwsolucoes.sistemanutricao.model.Nutricionista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface IngredienteNutricionistaRepository extends JpaRepository<IngredienteNutricionista, Long> {

    // Busca por nome e nutricionista
    Optional<IngredienteNutricionista> findByNomeAndNutricionista(String nome, Nutricionista nutricionista);

    // Lista todos ingredientes de um nutricionista
    List<IngredienteNutricionista> findByNutricionista(Nutricionista nutricionista);

    // Busca por parte do nome para um nutricionista específico
    List<IngredienteNutricionista> findByNomeContainingAndNutricionista(String nome, Nutricionista nutricionista);

    // Busca ingredientes com baixo carboidrato
    @Query("SELECT i FROM IngredienteNutricionista i WHERE i.carboidratoPor100g <= :maxCarboidratos AND i.nutricionista = :nutricionista")
    List<IngredienteNutricionista> findLowCarb(
            @Param("maxCarboidratos") BigDecimal maxCarboidratos,
            @Param("nutricionista") Nutricionista nutricionista);

    // Contagem de ingredientes por nutricionista
    long countByNutricionista(Nutricionista nutricionista);
}