package com.mjwsolucoes.sistemanutricao.dto;

public class IngredienteNutricionistaDTO {
}
