package com.mjwsolucoes.sistemanutricao.service;

import com.mjwsolucoes.sistemanutricao.model.Ingrediente;
import com.mjwsolucoes.sistemanutricao.repository.IngredienteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class IngredienteService {

    private final IngredienteRepository ingredienteRepository;

    public IngredienteService(IngredienteRepository ingredienteRepository) {
        this.ingredienteRepository = ingredienteRepository;
    }

    @Transactional(readOnly = true)
    public List<Ingrediente> listarTodos() {
        return ingredienteRepository.findAllByOrderByNomeAsc();
    }

    @Transactional(readOnly = true)
    public Optional<Ingrediente> buscarPorId(Long id) {
        return ingredienteRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<Ingrediente> buscarPorNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Termo de busca não pode ser vazio");
        }
        return ingredienteRepository.findByNomeContainingIgnoreCase(nome);
    }

    @Transactional(readOnly = true)
    public List<Ingrediente> buscarPorTeorProteicoMinimo(BigDecimal minimo) {
        if (minimo == null || minimo.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Valor mínimo de proteína inválido");
        }
        return ingredienteRepository.findComProteinaAcimaDe(minimo);
    }

    @Transactional(readOnly = true)
    public boolean existeComNome(String nome) {
        return ingredienteRepository.findByNomeIgnoreCase(nome).isPresent();
    }
}