package com.mjwsolucoes.sistemanutricao.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record IngredienteDTO(
        Long id,

        @NotBlank(message = "Nome é obrigatório")
        @Size(max = 100, message = "Nome deve ter no máximo 100 caracteres")
        String nome,

        @NotNull(message = "Proteína é obrigatória")
        @PositiveOrZero(message = "Proteína não pode ser negativa")
        @Digits(integer = 7, fraction = 2, message = "Proteína deve ter até 2 casas decimais")
        BigDecimal proteinaPor100g,

        @NotNull(message = "Carboidrato é obrigatório")
        @PositiveOrZero(message = "Carboidrato não pode ser negativo")
        @Digits(integer = 7, fraction = 2, message = "Carboidrato deve ter até 2 casas decimais")
        BigDecimal carboidratoPor100g,

        @NotNull(message = "Lipídio é obrigatório")
        @PositiveOrZero(message = "Lipídio não pode ser negativo")
        @Digits(integer = 7, fraction = 2, message = "Lipídio deve ter até 2 casas decimais")
        BigDecimal lipidioPor100g,

        @NotNull(message = "Sódio é obrigatório")
        @PositiveOrZero(message = "Sódio não pode ser negativo")
        @Digits(integer = 7, fraction = 2, message = "Sódio deve ter até 2 casas decimais")
        BigDecimal sodioPor100g,

        @NotNull(message = "Gordura saturada é obrigatória")
        @PositiveOrZero(message = "Gordura saturada não pode ser negativa")
        @Digits(integer = 7, fraction = 2, message = "Gordura saturada deve ter até 2 casas decimais")
        BigDecimal gorduraSaturadaPor100g
) {
    // Método para criar DTO a partir da entidade
    public static IngredienteDTO fromEntity(Ingrediente ingrediente) {
        return new IngredienteDTO(
                ingrediente.getId(),
                ingrediente.getNome(),
                ingrediente.getProteinaPor100g(),
                ingrediente.getCarboidratoPor100g(),
                ingrediente.getLipidioPor100g(),
                ingrediente.getSodioPor100g(),
                ingrediente.getGorduraSaturadaPor100g()
        );
    }

    // Método para converter DTO para entidade (útil para criação)
    public Ingrediente toEntity() {
        return new Ingrediente(
                this.id(),
                this.nome(),
                this.proteinaPor100g(),
                this.carboidratoPor100g(),
                this.lipidioPor100g(),
                this.sodioPor100g(),
                this.gorduraSaturadaPor100g()
        );
    }
}