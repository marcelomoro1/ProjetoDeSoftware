package com.mjwsolucoes.sistemanutricao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaNutricaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
